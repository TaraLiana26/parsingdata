<!DOCTYPE html>
<html>
<head>
	<title>Form Biodata</title>
</head>
<body>
	<b>FORM TAMBAH DATA</b>
	<form action="proses_tambah_data.php" method="POST">
	<table border="1">
		<tr>
			<td>
				NAMA
			</td>
			<td>
				<INPUT name="namaku" TYPE="TEXT" PLACEHOLDER="nama anda">
			</td>
		</tr>
		<tr>
			<td>
				PASSWORD
			</td>
			<td>
				<INPUT name="katasandiku" TYPE="PASSWORD" PLACEHOLDER="password anda">
			</td>
		</tr>
		<tr>
			
			<td>
				<INPUT  TYPE="submit" value="Kirim Data">
			</td>
		</tr>
	</table>
	</form>
</body>
</html>